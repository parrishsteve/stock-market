package com.parrishsystems.stock.repo

class Symbols {
    val symbols: MutableList<String> = mutableListOf()
}